<?php
// configuration
$serverName = "localhost";
$userName = "root";
$password = "";
$dbName = "Smart Farming System";
$charset="utf8mb4";

// database connection
try{
    $db = new PDO("mysql:host=$serverName;dbname=$dbName;charset=$charset", $userName, $password);
    $db->setAttribute( PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION );
}
catch(PDOException $e) {
    echo "I'm sorry, Garfield. I'm afraid I can't do that.";
    file_put_contents('PDOErrors.txt', $e->getMessage(), FILE_APPEND);
}
