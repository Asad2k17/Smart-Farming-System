<?php
//db connection
include_once "../../lib/connection.php";
// build query
$query="SELECT * FROM `faqs` ORDER BY id DESC ";
$stmt = $db->query("$query");
$faqs=$stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php
include_once"../element/header.php";
include_once"../element/nav.php";
?>

<body>


<section id="all-post">
    <div class="container">

    <div class="row">
        <div class="col-md-12 col-lg-12">
                <?php
                    foreach ($faqs as $faq):
                ?>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>প্রশ্নের বিষয়</th>
                    <th>প্রশ্নের বিস্তারিত</th>
                    <th>বিস্তারিত মতামত</th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                    <tr>
                        <td><?= $faq['category']?></td>
                        <td><?= $faq['problem']?></td>
                        <td><?= $faq['solution']?></td>
						<td>
                            <a href="edit.php?id=<?= $faq['id']?>"><button class="btn warning">Edit</button></a><br/><br/>
                            <a href="delete.php?id=<?= $faq['id']?>"><button class="btn danger">Delete</button></a>
                        </td>
                    </tr>
                    <?php
                        endforeach;
                    ?>
               </tbody>
           </table>
        </div>
    </div>
</div>
</section>


<!-- Footer goes here-->
<?php
include_once"../element/footer.php"; 
?>