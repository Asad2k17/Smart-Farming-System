<?php
//db connection
include_once "../../lib/connection.php";
// build query
$query="SELECT * FROM `faqs` ORDER BY id DESC ";
$stmt = $db->query("$query");
$faqs=$stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<?php
include_once"../element/header.php";
include_once"../element/nav.php";
?>
<body>

<section id="common-diseases">
    <div class="container">

    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12 ">

            <form action="search.php" method="POST" class="disease-form">
                <input type="text" name="query" placeholder="ফসলের নাম অনুসন্ধান করতে ইউনিকোড ব্যবহার করুন" required/>
                <input class="navbar-btn btn-info" type="submit" value="search"  />
            </form>
            

                <?php
                    foreach ($faqs as $faq){
                ?>

            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>প্রশ্নের বিষয়</th>
                    <th>প্রশ্নের বিস্তারিত</th>
                    <th>বিস্তারিত মতামত</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?php echo $faq['category'] ?></td>
                    <td><?php echo $faq['problem'] ?></td>
                    <td><?php echo $faq['solution'] ?></td>


                </tr>
                <?php
                    }
                    ?>
               </tbody>
           </table>
        </div>
    </div>
</div>
</section>
</body>






<!-- Footer goes here-->
<?php
include_once"../element/footer.php";
?>
