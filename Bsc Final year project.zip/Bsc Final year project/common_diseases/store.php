<?php

//db connection

include_once "../../lib/connection.php";

//build query
$query= "INSERT INTO `faqs` ( `category`, `problem`, `solution`) 
VALUES ( '".$_POST['category']."', '".$_POST['problem']."', '".$_POST['solution']."')";


//query execute
$result=$db->exec($query);

//Redirection to all post list
header("location:all-post.php");

