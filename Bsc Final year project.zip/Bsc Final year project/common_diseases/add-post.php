<?php
//db connection
include_once "../../lib/connection.php";
?>
<?php
include_once"../element/header.php";
include_once"../element/nav.php";
?>

<body>
<section id="add-post">
    <div class="container">
    <div class="row">
        <div class="col-md-12 col-lg-12">
            <form action="store.php" method="post">
                <fieldset><legend>Add New Post</legend>
                    <div class="form-group">
                        <label for="category">ফসলের নাম</label>
                        <input type="text"  class="form-control" id="category" name="category" placeholder="এথানে প্রশ্নের বিষয় / ফসলের নাম লিখুন" required="required">
                    </div>
                    <div class="form-group">
                        <label for="problem">প্রশ্নের বিস্তারিত</label>
                        <textarea  class="form-control" rows="10" cols="50" id="problem" name="problem" placeholder="এথানে প্রশ্নের বিস্তারিত লিখুন" required="required"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="solution">বিস্তারিত মতামত</label>
                        <textarea class="form-control" rows="20" cols="50" id="solution" name="solution" placeholder="এথানে বিস্তারিত মতামত লিখুন" required="required"></textarea>
                    </div>
                        <button type="submit" class="btn btn-success">Add Post</button>
                </fieldset>
            </form>
        </div>
    </div>
</div>
</section>


<!-- Footer goes here-->
<?php
include_once"../element/footer.php";
?>
