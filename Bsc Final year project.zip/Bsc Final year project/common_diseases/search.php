<?php
//db connection
include_once "../../lib/connection.php";

// gets value sent over search form
$search_query = $_GET['query'];

// you can set minimum length of the query if you want
$min_length = 3;
$sql="SELECT * FROM `faqs`
            WHERE (`category` LIKE '%".$search_query."%') OR (`solution` LIKE '%".$search_query."%')";

?>


<?php
include_once"../element/header.php";
?>
<body>
<?php
include_once ("../element/nav.php");
?>
<section id="search">
<div class="container">
    <div class="row">
        <div class="col-sm-12 col-md-12 col-lg-12">
            <form action="search.php" method="GET" class="search">
                <input type="text" name="query" required/>
                <input class="navbar-btn btn-info" type="submit" value="search" />
            </form>
            <div class="solution">
                <h4>Happy Farming</h4>
            </div>
            <?php
            if(strlen($search_query) >= $min_length){ // if query length is more or equal minimum length then

                $search_query = htmlspecialchars($search_query);


                $raw_results = $db->query("$sql");


                if($raw_results->rowCount() > 0){ // if one or more rows are returned do following

                    while($results = $raw_results->fetchAll(PDO::FETCH_ASSOC)):
                        // $results = $raw_results->fetchAl(PDO::FETCH_ASSOC) puts data from database into array, while it's valid it does the loop
                        foreach ($results as $result):

                ?>
            <table class="table table-bordered">
                <thead>
                <tr>
                    <th>প্রশ্নের বিষয়</th>
                    <th>প্রশ্নের বিস্তারিত</th>
                    <th>বিস্তারিত মতামত</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td><?= $result['category']?></td>
                    <td><?= $result['problem']?></td>
                    <td><?= $result['solution']?></td>

                </tr>
                <?php
                        endforeach;
                    endwhile;

                }
                else{ // if there is no matching rows do following
                    echo "No results";
                }

            }
            else{ // if query length is less than minimum
                //echo "Minimum length is ".$min_length;
            }
            ?>
            </tbody>
            </table>

        </div>
    </div>
</div>

<!-- Footer goes here-->
</section>
<?php
include_once"../element/footer.php";
?>