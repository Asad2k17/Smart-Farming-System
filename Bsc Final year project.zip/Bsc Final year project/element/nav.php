<?php
    include_once "../element/header.php"
?>
<header>
    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="navbar-brand">
                <a class="logo js-scroll-trigger"><p><i class="fas fa-tree"></i> Smart Farming System</p></a>
            </div>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavDropdown">
                <ul class="navbar-nav left-menu ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="all-post.php">All Post</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="search.php">Search</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="add-post.php">Add Post</a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</header>