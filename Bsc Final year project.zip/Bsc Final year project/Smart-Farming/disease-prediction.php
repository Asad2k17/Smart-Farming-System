<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="application-name" content="">
	<meta name="description" content="">
	<link rel="icon" href="img/favicon.png">
	<title>Smart Farming System- Disease Prediction</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css">

	<!-- Normalize -->
	<link rel="stylesheet" type="text/css" href="css/vendor/normalize.css">

	<!-- Lity -->
	<link rel="stylesheet" type="text/css" href="css/vendor/lity.css">

	<!-- Font Awesome -->
	<link rel="stylesheet" type="text/css" href="css/vendor/font-awesome/css/font-awesome.min.css">

	<!-- Font Poppins -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,600" rel="stylesheet">

	<!-- Main Stylesheet -->
	<link rel="stylesheet" href="style.css">
	
	<!-- Responsive Css -->
	<link rel="stylesheet" type="text/css" href="responsive.css">
</head>
<body>
    <header>
	    <div class="container">
	        <nav class="navbar navbar-expand-lg navbar-light bg-light">
	            <div class="navbar-brand">
	                <a class="logo js-scroll-trigger" href="index.php"><p><i class="fas fa-tree"></i> Smart Farming System</p></a>
	            </div>
	            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
	                <span class="navbar-toggler-icon"></span>
	            </button>
	            <div class="collapse navbar-collapse" id="navbarNavDropdown">
	                <ul class="navbar-nav left-menu ml-auto">
	                    <li class="nav-item">
	                        <a class="nav-link" href="index.php">Home</a>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" href="question-answer.php">Question & answer</a>
	                    </li>
	                    <li class="nav-item dropdown" >
	                        <a class="nav-link" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown">Blog</a>
	                        <ul class="dropdown-menu">
	                        	<li class="nav-item">
	                        		<a href="fruit-blogs.php" class="dropdown-item">Fruit-Root Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="vegetables-blog.php" class="dropdown-item">Vegetables Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="roof-top.php" class="dropdown-item">Roof Top Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="rice-blog.php" class="dropdown-item">Information & Cultivation of Rice</a>
	                        	</li>
	                        	<li>
	                        		<a href="flower-blog.php" class="dropdown-item">Flower Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="prosperous.php" class="dropdown-item">Prosperous Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="medicinal.php" class="dropdown-item">Medicinal Plants</a>
	                        	</li>
	                        	<li>
	                        		<a href="fertilizer.php" class="dropdown-item">Fertilizer & Pesticide Informations</a>
	                        	</li>
	                        </ul>
	                    </li>
	                    <li class="nav-item dropdown" >
	                        <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown">Disease Prediction</a>
	                        <ul class="dropdown-menu">
	                        	<li class="nav-item">
	                        		<a href="fruit-disease.php" class="dropdown-item">Fruit-Root Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="vegetables-disease.php" class="dropdown-item">Vegetables Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="roof-top-disease.php" class="dropdown-item">Roof Top Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="rice-blog-disease.php" class="dropdown-item">Information & Cultivation of Rice</a>
	                        	</li>
	                        	<li>
	                        		<a href="flower-disease.php" class="dropdown-item">Flower Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="prosperous-disease.php" class="dropdown-item">Prosperous Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="medicinal-disease.php" class="dropdown-item">Medicinal Plants</a>
	                        	</li>
	                        </ul>
	                    </li>
	                    <li class="nav-item dropdown">
	                    	<a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown">Doctor Directory</a>
	                    	<ul class="dropdown-menu">
	                    		<li class="nav-item">
	                        		<a href="dhaka-division.php" class="dropdown-item">Dhaka Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="chittagong-division.php" class="dropdown-item">Chittagong Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="rajshahi-division.php" class="dropdown-item">Rajshahi Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="rangpur-division.php" class="dropdown-item">Rangpur Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="khulna-division.php" class="dropdown-item">Khulna Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="sylhet-division.php" class="dropdown-item">Sylhet Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="barishal-division.php" class="dropdown-item">Barishal Division</a>
	                        	</li>
	                    	</ul>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" href="register.php">Register</a>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" href="login.php">Log In</a>
	                    </li>
	                </ul>
	            </div>
	        </nav>
	    </div>
	</header>
    <section id="disease-prediction">
    	<div class="container">
    		<div class="row">
    			<div class="col-sm-12 col-md-12 col-lg-12">
    				
    			</div>
    		</div>
    	</div>
    </section>
	<footer id="footer">
		<div class="copyright-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12">
						<p class="copyright-text">Copyright © 2019 <a href="index.php">Smart Farming System</a>.</p>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="copyright-nav">
							<ul>
								<li><a href="about.php">About</a></li>
								<li><a href="contact.php">Contact</a></li>
								<li><a href="#" target="_blank">Facebook</a></li>
								<li><a href="#" target="_blank">Instagram</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	
	<script src="js/vendor/tether.min.js"></script>
	<script src="js/vendor/popper.min.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/vendor/jquery.min.js"></script>
	<script src="js/vendor/font-awesome.js"></script>
</body>
</html>