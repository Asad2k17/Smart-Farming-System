<?php

//db connection
include_once "../../lib/connection.php";

//build query
//$query= "UPDATE `faqs` SET  `category` = '".$_POST['category']."', `problem` = '".$_POST['problem'] WHERE `id` = ".$_POST['id'];
$query="UPDATE `faqs` SET `category` = '".$_POST['category']."', `problem` = '".$_POST['problem']."', `solution` = '".$_POST['problem']."' WHERE `faqs`.`id` = ".$_POST['id'];

//query execute
$result=$db->exec($query);

//Redirection to all post
header("location:all-post.php");

?>