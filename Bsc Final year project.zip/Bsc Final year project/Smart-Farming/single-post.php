<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="application-name" content="">
	<meta name="description" content="">
	<link rel="icon" href="img/favicon.png">
	<title>Single Post</title>

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="css/vendor/bootstrap.min.css">

	<!-- Normalize -->
	<link rel="stylesheet" type="text/css" href="css/vendor/normalize.css">

	<!-- Lity -->
	<link rel="stylesheet" type="text/css" href="css/vendor/lity.css">

	<!-- Font Awesome -->
	<link rel="stylesheet" type="text/css" href="css/vendor/font-awesome/css/font-awesome.min.css">

	<!-- Font Poppins -->
	<link href="https://fonts.googleapis.com/css?family=Poppins:400,600" rel="stylesheet">

	<!-- Main Stylesheet -->
	<link rel="stylesheet" href="style.css">
	
	<!-- Responsive Css -->
	<link rel="stylesheet" type="text/css" href="responsive.css">


</head>
<body>
    <header>
	    <div class="container">
	        <nav class="navbar navbar-expand-lg navbar-light bg-light">
	            <div class="navbar-brand">
	                <a class="logo js-scroll-trigger" href="index.php"><p><i class="fas fa-tree"></i> Smart Farming System</p></a>
	            </div>
	            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
	                <span class="navbar-toggler-icon"></span>
	            </button>
	            <div class="collapse navbar-collapse" id="navbarNavDropdown">
	                <ul class="navbar-nav left-menu ml-auto">
	                    <li class="nav-item">
	                        <a class="nav-link" href="index.php">Home</a>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" href="question-answer.php">Question & answer</a>
	                    </li>
	                    <li class="nav-item dropdown" >
	                        <a class="nav-link" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown">Blog</a>
	                        <ul class="dropdown-menu">
	                        	<li class="nav-item">
	                        		<a href="fruit-blogs.php" class="dropdown-item">Fruit-Root Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="vegetables-blog.php" class="dropdown-item">Vegetables Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="roof-top.php" class="dropdown-item">Roof Top Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="rice-blog.php" class="dropdown-item">Information & Cultivation of Rice</a>
	                        	</li>
	                        	<li>
	                        		<a href="flower-blog.php" class="dropdown-item">Flower Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="prosperous.php" class="dropdown-item">Prosperous Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="medicinal.php" class="dropdown-item">Medicinal Plants</a>
	                        	</li>
	                        	<li>
	                        		<a href="fertilizer.php" class="dropdown-item">Fertilizer & Pesticide Informations</a>
	                        	</li>
	                        </ul>
	                    </li>
	                    <li class="nav-item dropdown" >
	                        <a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown">Disease Prediction</a>
	                        <ul class="dropdown-menu">
	                        	<li class="nav-item">
	                        		<a href="fruit-disease.php" class="dropdown-item">Fruit-Root Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="vegetables-disease.php" class="dropdown-item">Vegetables Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="roof-top-disease.php" class="dropdown-item">Roof Top Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="rice-blog-disease.php" class="dropdown-item">Information & Cultivation of Rice</a>
	                        	</li>
	                        	<li>
	                        		<a href="flower-disease.php" class="dropdown-item">Flower Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="prosperous-disease.php" class="dropdown-item">Prosperous Cultivation</a>
	                        	</li>
	                        	<li>
	                        		<a href="medicinal-disease.php" class="dropdown-item">Medicinal Plants</a>
	                        	</li>
	                        </ul>
	                    </li>
	                    <li class="nav-item dropdown">
	                    	<a class="nav-link" id="navbarDropdownMenuLink" data-toggle="dropdown">Doctor Directory</a>
	                    	<ul class="dropdown-menu">
	                    		<li class="nav-item">
	                        		<a href="dhaka-division.php" class="dropdown-item">Dhaka Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="chittagong-division.php" class="dropdown-item">Chittagong Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="rajshahi-division.php" class="dropdown-item">Rajshahi Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="rangpur-division.php" class="dropdown-item">Rangpur Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="khulna-division.php" class="dropdown-item">Khulna Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="sylhet-division.php" class="dropdown-item">Sylhet Division</a>
	                        	</li>
	                    		<li class="nav-item">
	                        		<a href="barishal-division.php" class="dropdown-item">Barishal Division</a>
	                        	</li>
	                    	</ul>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" href="register.php">Register</a>
	                    </li>
	                    <li class="nav-item">
	                        <a class="nav-link" href="login.php">Log In</a>
	                    </li>
	                </ul>
	            </div>
	        </nav>
	    </div>
	</header>
	<section id="single-post">
		<div class="container">
			<div class="row row-wrapper">
				<div class="col-sm-12 col-md-12 col-lg-12">
					<article class="blog-post-item">
						<div class="feature-image">
							<img src="img/blog9.jpg" alt="blog">
						</div>
						<ul class="post-meta">
							<li>By <a href="#">Sahinur Salafee</a></li>
							<li><i class="far fa-clock"></i> 23 July 2019</li>
						</ul><div class="blog-title">
							<h3><a href="#">কৃষি বাংলাদেশের বৃহত্তম কর্মসংস্থান খাত।</a></h3>
						</div>
						<div class="blog-description">
							<p>কৃষি বাংলাদেশের বৃহত্তম কর্মসংস্থান খাত। কর্মসংস্থান সৃষ্টি, দারিদ্র্য বিমোচন, মানব সম্পদ উন্নয়ন, খাদ্য নিরাপত্তা ইত্যাদির মতো বৃহৎ মৎস্য অবকাঠামো বিষয়ক এই ক্ষেত্রের কর্মকাণ্ডের উপর প্রভাব ফেলেছে। বাংলাদেশিদের বহুবিবাহ কৃষি থেকে জীবিকা অর্জন করে। যদিও ধান ও পাট প্রাথমিক ফসল, তবে গম আরও বেশি গুরুত্ব দিচ্ছে। উত্তর পূর্বাঞ্চলে চা উৎপন্ন হয়। বাংলাদেশের উর্বর মাটি এবং সাধারণত প্রশস্ত পানি সরবরাহের কারণে ...</p><br>
							<p>বাংলাদেশ বিশ্বের সবচেয়ে ঘনবসতিপূর্ণ দেশগুলির একটি। ইলিনয়েসের আকার, বাংলাদেশের মোট জনসংখ্যা 156 মিলিয়ন, অর্ধেক জনসংখ্যার মার্কিন যুক্তরাষ্ট্র। দারিদ্র্য থেকে সাম্প্রতিক অগ্রগতি সত্ত্বেও এবং সাক্ষরতা এবং জীবন প্রত্যাশা হিসাবে মানুষের উন্নয়ন সূচক বৃদ্ধি, আয় এবং খরচ হার মধ্যে অসমতা (ইউএনডিপি 2005) বৃদ্ধি পেয়েছে। জনসংখ্যার 32% জাতীয় দারিদ্র্য সীমার নীচে বসবাস করে, যাদের অধিকাংশই নারী ও শিশু। শিশুটির প্রাদুর্ভাব (5 বছরের নীচে) অপুষ্টিতে 33%, বিশ্বের অন্যতম সর্বোচ্চ।</p>
							<p class="align-center">
								<em>"দারিদ্র্য ও মানব উন্নয়ন সূচকের মতো এলাকায় সাম্প্রতিক অগ্রগতি সত্ত্বেও সাক্ষরতা এবং জীবনধারা, আয় ও খরচ হারের অসমতা বেড়েছে, দারিদ্র্য সীমার নিচে বসবাসকারী 32% জনসংখ্যার জনসংখ্যার সঙ্গে বেড়েছে।"</em>
							</p><br>
							<p>নারী ও মেয়েদের প্রতি বৈষম্যমূলক বৈষম্যমূলক দারিদ্র্য বাংলাদেশী সমাজের মধ্যে বৈষম্য ও বর্জনের ফলে সিদ্ধান্ত গ্রহণ প্রক্রিয়ার মধ্যে তাদের অধিকার ও প্রভাব প্রতিষ্ঠার সংগ্রামে পরিণত হয়। যেমন ডোযি, বাল্য বিয়ে এবং শেষ খাবার খাওয়ার বিনিময়ে ঐতিহ্যগত অনুশীলন মেয়েরা ও মহিলাদের জন্য বিপজ্জনক সমাজতান্ত্রিক প্রসঙ্গ তৈরি করেছে।</p><br>
							<p>1971 সালে স্বাধীনতার পর রাজনৈতিক অস্থিরতার পর 1990 সালে বাংলাদেশ গণতন্ত্র হিসেবে আবির্ভূত হয়েছিল। তবে আজকের দিনে রাজনৈতিক অস্থিতিশীলতা ও আন্দোলন, দুর্বল ও নিখুঁত শাসন এবং 'প্রাতিষ্ঠানিক রাজনৈতিক সহিংসতা' (ইউএনডিপি ২005) থেকে বাংলাদেশ ভুগছে। এই জলবায়ুটি বিশ্বের এনজিও কর্মকাণ্ডের সর্বাধিক ঘনত্বের দিকে পরিচালিত হয়েছে, যা দরিদ্রতম দরিদ্রের সাথে কাজ করে, বাংলাদেশী সংস্কৃতির মধ্যে প্রায়ই প্রান্তিক হয়ে থাকে, পরিষেবা বিতরণ থেকে শুরু করে সম্প্রদায়ের যৌথবাহিনীর সাথে কাজ করে।</p><br>
							<p>ক্রমবর্ধমান সাধারণ পরিবেশগত বিপর্যয়ের কারণে বাংলাদেশ এর স্থায়িত্ব আরো হুমকির মুখে রয়েছে, এবং এটি জলবায়ু পরিবর্তনের প্রভাবগুলির জন্য অত্যন্ত ঝুঁকিপূর্ণ। অধিকন্তু, দারিদ্র্য সীমার ঊর্ধ্বে অনেক বাংলাদেশিদের অর্থনৈতিক নিরাপত্তা জাল নেই, এবং প্রাকৃতিক দুর্যোগের কারণে তারা দারিদ্র্যসীমার নিচে পড়ে বা তাদের চাকরি হারাতে পারে।</p>
						</div>
						<div class="social-icon">
							<a href="#"><i class="fab fa-facebook-f"></i></a>
							<a href="#"><i class="fab fa-instagram"></i></a>
							<a href="#"><i class="fab fa-twitter"></i></a>
						</div>
					</article>
					<div class="comment-section">
						<div class="title">
							<h3>৩ টি মন্তব্য </h3>
						</div>
						<div class="user-comments">
							<div class="user">
								<a href="#"><img src="img/user3.jpg" alt=""></a>
								<div class="comment-wrapper clearfix">
									<h6 class="user-name">Razu Ahmed</h6>
									<div class="comment-time">
										<p>May 30, 2019 at 5:43pm</p>
									</div>
									<p class="user-comment">ক্রমবর্ধমান সাধারণ পরিবেশগত বিপর্যয়ের কারণে বাংলাদেশ এর স্থায়িত্ব আরো হুমকির মুখে রয়েছে, এবং এটি জলবায়ু পরিবর্তনের প্রভাবগুলির জন্য অত্যন্ত ঝুঁকিপূর্ণ।</p>
									<div class="reply"> <a href="#">Reply</a> </div>
									<div class="edit"> <a href="#">Edit</a> </div>
								</div>
								<div class="user">
								<a href="#"><img src="img/user2.jpg" alt=""></a>
								<div class="comment-wrapper clearfix">
									<h6 class="user-name">Sahinur Salafee</h6>
									<div class="comment-time">
										<p>May 31, 2019 at 5:00pm</p>
									</div>
									<p class="user-comment">কৃষি বাংলাদেশের বৃহত্তম কর্মসংস্থান খাত। কর্মসংস্থান সৃষ্টি, দারিদ্র্য বিমোচন, মানব সম্পদ উন্নয়ন, খাদ্য নিরাপত্তা ইত্যাদির মতো বৃহৎ মৎস্য অবকাঠামো বিষয়ক এই ক্ষেত্রের কর্মকাণ্ডের উপর প্রভাব ফেলেছে। </p>
									<div class="reply"> <a href="#">Reply</a> </div>
									<div class="edit"> <a href="#">Edit</a> </div>
								</div>
							</div>
							</div>
							<div class="user">
								<a href="#"><img src="img/user1.jpg" alt=""></a>
								<div class="comment-wrapper clearfix">
									<h6 class="user-name">Arifa Ruhi</h6>
									<div class="comment-time">
										<p>May 25, 2019 at 7.50pm</p>
									</div>
									<p class="user-comment">নারী ও মেয়েদের প্রতি বৈষম্যমূলক বৈষম্যমূলক দারিদ্র্য বাংলাদেশী সমাজের মধ্যে বৈষম্য ও বর্জনের ফলে সিদ্ধান্ত গ্রহণ প্রক্রিয়ার মধ্যে তাদের অধিকার ও প্রভাব প্রতিষ্ঠার সংগ্রামে পরিণত হয়।</p>
									<div class="reply"> <a href="#">Reply</a> </div>
									<div class="edit"> <a href="#">Edit</a> </div>
								</div>
							</div>
							<div class="pagination">
								<ul>
									<li><a href="#">1</a></li>
									<li><a href="#">2</a></li>
									<li><a href="#">3</a></li>
									<li><a href="#">...</a></li>
									<li><a href="#">8</a></li>
									<li><a href="#" class="right-arrow"><i class="fas fa-caret-right"></i></a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="leave-comment">
						<div class="page-title">
							<h4><span>মতামত দিন</span></h4>
						</div>
						<form name="comment_form" method="post" class="comment-form">
							<div class="half-width">
								<input type="text" placeholder="নাম*" name="user_name">
								<input type="email" placeholder="আপনার ইমেইল *" name="email">
							</div>
							<div class="full-width">
								<textarea name="comment" id="" cols="30" rows="10" placeholder="আপনার মন্তব্য "></textarea>
							</div>
							<button class="tm-button">জমা দিন</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</section>
	<footer id="footer">
		<div class="copyright-area">
			<div class="container">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-12">
						<p class="copyright-text">Copyright © 2019 <a href="index.php">Smart Farming System</a>.</p>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12">
						<div class="copyright-nav">
							<ul>
								<li><a href="about.php">About</a></li>
								<li><a href="contact.php">Contact</a></li>
								<li><a href="#" target="_blank">Facebook</a></li>
								<li><a href="#" target="_blank">Instagram</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</footer>
	
	<script src="js/vendor/tether.min.js"></script>
	<script src="js/vendor/popper.min.js"></script>
	<script src="js/vendor/bootstrap.min.js"></script>
	<script src="js/vendor/jquery.min.js"></script>
	<script src="js/vendor/font-awesome.js"></script>
</body>
</html>