<?php

//db connection
include_once "../../lib/connection.php";

// build query
$query="DELETE FROM `faqs` WHERE `id` = ".$_GET['id'];

//query execute
$result=$db->exec($query);

//Redirection to all post of common diseases list
header("location:all-post.php");

