<?php
/**
 * Created by PhpStorm.
 * User: mcebd
 * Date: 5/27/2019
 * Time: 2:00 AM
 */

//db connection
include_once "../../lib/connection.php";
// build query
$query="SELECT * FROM `faqs` WHERE id= ".$_GET['id'];
$stmt = $db->query("$query");
$faq=$stmt->fetch(PDO::FETCH_ASSOC);
?>
<?php
include_once"../element/header.php";
include_once"../element/nav.php";
?>

<body>

<section id="edit">
    <div class="container">

    <div class="row">
        <div class="col-lg-12 col-md-12">
            <form action="update.php" method="post">
                <fieldset><legend>Update Post</legend>

                    <input type="hidden" value="<?= $faq['id']?>" class="form-control" id="id" name="id">

                    <div class="form-group">
                        <label for="category">প্রশ্নের বিষয়</label>
                        <input type="text" value="<?= $faq['category']?>" class="form-control" id="category" name="category" required="required">
                    </div>
                    <div class="form-group">
                        <label for="problem">প্রশ্নের বিস্তারিত</label>
                        <textarea  class="form-control" rows="10" cols="50" id="problem" name="problem" required="required"><?= $faq['problem']?></textarea>
                    </div>
                    <div class="form-group">
                        <label for="solution">বিস্তারিত মতামত</label>
                        <textarea class="form-control" rows="20" cols="50" id="solution" name="solution" required="required"><?= $faq['solution']?></textarea>
                    </div>
                        <button type="submit" class="btn btn-success">Update</button>
                </fieldset>
            </form>
        </div>
    </div>
</div>
</section>


<!-- Footer goes here-->
<?php
include_once"../element/footer.php";
?>
